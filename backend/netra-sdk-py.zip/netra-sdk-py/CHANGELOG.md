# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog and this project adheres to Semantic Versioning.


## [0.1.77] - 2026-03-27
- Added custom-metric utility in SDK
- Added support for custom-metric in dashboard utility


## [0.1.76] - 2026-03-19

- Update block instrument functionality to correctly block Redis and SQLAlchemy
- Remove httpx based check for blocking url


## [0.1.75] - 2026-03-18

- Added custom instrumentation for Claude Agent SDK


## [0.1.74] - 2026-03-13

- Add utility for prompt management


## [0.1.73] - 2026-03-12

- Extended dependency support for opentelemetry and traceloop-sdk
- Added TTFT for Cerebras and Groq instrumentation


## [0.1.72] - 2026-02-24

- Fixed bug in blocking internal request calls

## [0.1.71] - 2026-02-24

- Lock all dependency versions to avoid conflicts

## [0.1.69] - 2026-02-19

- Added support for blocked URL pattern in span blocking utility
- Fixed bug in run item failure reporting when an exception is raised from netra agent

## [0.1.68] - 2026-02-17

- Added support for audio duration & character count metric in dashboard query

## [0.1.67] - 2026-02-06

- Added support for simulation utility to trigger multi-turn simulation

## [0.1.66] - 2026-02-02

- Added Service and Environment filter for session summary and session stats dashboard utilities

## [0.1.65] - 2026-01-27

- Added session summary and session stats dashboard utilities

## [0.1.64] - 2026-01-27

- Added session summary and session stats dashboard utilities

## [0.1.63] - 2026-01-21

- Added support for first token time in OpenAI & Google GenAI instrumentations

## [0.1.62] - 2026-01-19

- Fixed bug in dashboard query models
- Added support for auto evaluation
- Added support for turn-based evaluation

## [0.1.61] - 2026-01-14

- Added dashboard-query utility

## [0.1.60] - 2025-12-22

- Fixed conversation attribute handling to use OTel context first, then fallback to SessionManager spans
- Added backward compatability and bug fixes in ElevenLabs instrumentation
- Added utility for subscription based trace blocking

## [0.1.59] - 2025-12-15

- Added support for Cartesia, ElevenLabs and Deepgram voice agent instrumentations

## [0.1.58] - 2025-11-28

- Added support for explicit filter params in usage utilities

## [0.1.57] - 2025-11-28

- Added support for trace list, and span list in usage tracking utility

## [0.1.56] - 2025-11-26

- Extended usage tracking utility to support cost tracking

## [0.1.56] - 2025-11-26

- Extended usage tracking utility to support cost tracking

## [0.1.55] - 2025-11-20

- Added utility to get session and tenant based usage
- Refactored litellm instrumentation
- Fixed bug in capturing ADK tool call args

## [0.1.54] - 2025-11-18

- Added support for agent type in spans

## [0.1.53] - 2025-11-17

- Added custom instrumentation for ADK framework
- Refactored DSPy instrumentation

## [0.1.52] - 2025-11-11

- Fixed attribute max length issue

## [0.1.51] - 2025-11-10

- Added custom instrumentation for Cerebras framework
- Fixed bug in traceloop instrumentation

## [0.1.50] - 2025-11-07

- Added custom dataset and entries

## [0.1.49] - 2025-11-06

- Fixed token count calculation for OpenAI response API

## [0.1.48] - 2025-11-05

- Added custom instrumentation for Groq framework

## [0.1.47] - 2025-10-21

- Added support for existing tracer provider usage

## [0.1.46] - 2025-10-17

- Fixed exception during add conversation
- Added support for observation type in spans

## [0.1.45] - 2025-09-29

- Added utility to locally block specific spans within a particular span scope.

## [0.1.44] - 2025-09-29

- Added utility to globally block specific spans from being exported to the tracing backend.

## [0.1.43] - 2025-09-17

- Fixed conversation content length issue
- Added utils module to handle common tasks

## [0.1.42] - 2025-09-09

- Refactored conversation attribute format to be more consistent with OpenTelemetry

## [0.1.41] - 2025-09-09

- Refactored codebase to remove duplicate code

## [0.1.40] - 2025-09-08

- Added span level conversation support

## [0.1.39] - 2025-09-02

- Refactored code to remove duplicate code

## [0.1.38] - 2025-09-02

- Fixed instrumentation name detection issue

## [0.1.37] - 2025-09-01

- Fixed context detachment issue in session manager

## [0.1.36] - 2025-09-01

- Added a trace level method set_prompt to set prompt on any active span

## [0.1.35] - 2025-09-01

- Patch fix for set_input and set_output methods to set attributes on root span if no span is provided
- Patch fix to create streaming aware decorators

## [0.1.34] - 2025-08-29

- Changed block spans from being exported to block root level spans from being exported

## [0.1.33] - 2025-08-29

- Added utility to block specific spans from being exported to the tracing backend.
- Fixed context detachment issue in span wrapper.

## [0.1.32] - 2025-08-28

- Added support for scrubbing sensitive data from spans.

## [0.1.31] - 2025-08-28

- Added custom instrumentation for LiteLLM framework

## [0.1.30] - 2025-08-27

- Added utility to set input and output data for any active span in a trace

[0.1.78]: https://github.com/KeyValueSoftwareSystems/netra-sdk-py/tree/main
